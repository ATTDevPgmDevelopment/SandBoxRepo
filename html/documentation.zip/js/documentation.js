function apiPageInit() {
	var methodName = getUrlParam('method');
	var selectedTabNumber = methodName == null ? 0 : 1;

	$("#overview-methods-tabs").tabs({ selected: selectedTabNumber });
	$(".iNeedTabified").tabs();

	$(".Operation").hide();
	$(".Operation:first").show();

	$("#methodSelect").change(function() {                      
		var selectedMethod = $("#methodSelect").val();
		showOnlySelectedMethod(selectedMethod);
	});

	$("#environmentSelect").change(function() {                      
		var selectedEnvironment = $("#environmentSelect").val();
		if(selectedEnvironment == "html5") {
			var html5Url = $("#apiExternalLinkHtml5").val();
			var htmlWin = window.open(html5Url,"_html5");
			htmlWin.focus();
		}
		if(selectedEnvironment == "mssdk"){
			var mssdkUrl = $("#apiExternalLinkMssdk").val();
			var mssdkWin = window.open(mssdkUrl,"_mssdk");
			mssdkWin.focus();
		}
		$("#environmentSelect").val("rest");
	});
	
	$("table.parametersTable tr:odd").addClass("parameterAlternateRow");
	$("table.errorsTable tr:odd").addClass("errorsAlternateRow");
	
	selectDefaultMethod(methodName);
	rewriteNavigationUrls();
	rewriteErrorCodeUrls();
	decorateNavigation("apis");
}

function errorPageInit() {
	rewriteNavigationUrls();
	rewriteErrorCodeUrls();
	$("table.errorsTable tr:odd").addClass("errorsAlternateRow");
	decorateNavigation("errors");
}

function findTabIndex(methodName, providerName){
	var index = 0;
	var matchedIndex = 0;
	$("div#provider-tabs" + methodName + " > ul a").filter( function() {
		if(this.name != providerName)
		{
			index++;
		}
		else
		{
			matchedIndex = index;
			return matchedIndex;
		}
	});
	return matchedIndex;
}

function decorateNavigation(navigationPath) {
	$(".menuList a").removeClass("selected").removeClass("parentLevel");
	
	if(navigationPath == "apis")
	{
		var apiNumber = $("input[name=apiNumber]").val();
		var version = $("input[name=version]").val();                    
		$(".menuList a#" + apiNumber + "-" + version).addClass("selected");
		$(".menuList a#apis").addClass("parentLevel");
	} else {
		$(".menuList a#errors").addClass("selected").addClass("parentLevel");
	}
}
function rewriteNavigationUrls() {
	var passedItemId = getUrlParam('passedItemId');
	if(passedItemId==null){
		rewriteNavigationUrlsStandAlone();
	} else {
		rewriteNavigationUrlsDevPortal(passedItemId);
	}
}
function rewriteNavigationUrlsDevPortal(passedItemId) {
	var baseUrl = window.location.pathname.replace(/((basicTemplate\.jsp).*)/,"");

	$("ul.menuList a").each(function() {
		var currentUrl = $(this).attr('href');
		// Errors
		if(currentUrl.match(/Errors\/index\.html/)) {
			$(this).prop('href', baseUrl + "basicTemplate.jsp?passedItemId="+passedItemId+"&error=content");
		} else {
			// API
			var rewritten = currentUrl.replace(/(REST)\/(.*?)\/(.*?)\/.*\.html/,"basicTemplate.jsp?passedItemId="+passedItemId+"&api=$2&version=$3");
			$(this).prop('href', baseUrl + rewritten);
		}
	});
}
function rewriteNavigationUrlsStandAlone() {
	var baseUrl = window.location.pathname.replace(/((REST|Errors).*)/,"");

	$("ul.menuList a").each(function() {
		$(this).prop('href', baseUrl + $(this).attr('href'));
	});
}
function rewriteErrorCodeUrls() {
	var passedItemId = getUrlParam('passedItemId');
	if(passedItemId==null){
		rewriteErrorCodeUrlsStandAlone();
	} else {
		rewriteErrorCodeUrlsDevPortal(passedItemId);
	}
}
function rewriteErrorCodeUrlsDevPortal(passedItemId) {
	var baseUrl = window.location.pathname.replace(/((basicTemplate\.jsp).*)/,"");
	$(".errorsTable td a").each(function() {
		var currentUrl = $(this).attr('href');
	
		var rewritten = currentUrl.replace(/.*?([\w]{7})\.html/,"basicTemplate.jsp?passedItemId="+passedItemId+"&error=$1");
		$(this).prop('href', baseUrl + rewritten);
	});
	$("#errorsIndexLink").each(function() {
		$(this).prop('href', baseUrl + "basicTemplate.jsp?passedItemId="+passedItemId+"&error=content");
	});
}

function rewriteErrorCodeUrlsStandAlone() {
	$(".errorsTable td a").each(function() {
		var errorCodeFileName = $(this).attr('href');
		// change 0000003.html to error_detail.html?error=0000003
		var rewriteFileName = errorCodeFileName.replace(/([\w]{7})\.html/,"error_detail.html?error=$1");
		$(this).prop('href', rewriteFileName);
	});
}

function selectDefaultMethod(methodName){
	var selectedOptionValue = 'operation' + methodName;
	$("#methodSelect option").filter(function() {
		var matched = this.value == selectedOptionValue;
		if(matched){
			showOnlySelectedMethod(selectedOptionValue);
		}
		return matched; 
	}).attr('selected', true);

}

function showOnlySelectedMethod(selectedOptionValue) {
	$(".Operation").hide();
	$("div#" + selectedOptionValue).show();
	
	var providerName = getUrlParam('provider');
	var operationNumber = selectedOptionValue.match(new RegExp(/[\d]+/));
	
	var selectedProviderTab = findTabIndex(operationNumber, providerName);
	$("div[id*=provider-tabs]").tabs( "option", "selected", selectedProviderTab );
}

function getUrlParam(key) {
	key = key.replace(/[*+?^$.\[\]{}()|\\\/]/g, "\\$&"); // escape RegEx meta chars
	var match = location.search.match(new RegExp("[?&]"+key+"=([^&]+)(&|$)"));
	return match && decodeURIComponent(match[1].replace(/\+/g, " "));       
}

function searchErrorCodes() {		
	var searchTerm = $("input[name=errorSearchInput]").val();
	
	if(searchTerm == null || searchTerm == ''){
		$("#searchResultsSection").removeClass("hidden");
		$("#searchResultsText").text("Please enter an error code.");
		return;
	}

	searchTerm = padErrorCode(searchTerm);
	
	var matchingElements = $(".errorsTable a[href*=" + searchTerm + "]").filter(
		function() {
			var matched = "" + this.href.match(new RegExp(/[\d]{7}/));
			var errorCode = matched.substring(0,5);
			return searchTerm == errorCode;
		}
	);
	
	if(matchingElements.size() > 0)
	{
		matchingElements[0].click();
	} else {
		$("#searchResultsSection").removeClass("hidden");
		$("#searchResultsText").text("No Results found.  Please try again.");
		return;
	} 
}

function padErrorCode(errCode)
{
	var pad = "00000";
	return pad.substring(0, pad.length - errCode.length) + errCode;
}