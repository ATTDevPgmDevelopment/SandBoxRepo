var apiDocService = new function() {
	

	
	//public
	this.apiPageInit = function() {	
		var parsedApiUrlObj = new ParsedApiUrl(window.location.href);
		var operationId = getOperationId(parsedApiUrlObj.methodName);
		var selectedTabNumber = operationId == 0 ? 0 : 1;

		$("#overview-methods-tabs").tabs({
			selected : selectedTabNumber
		});
		$(".iNeedTabified").tabs();

		$(".Operation").hide();
		$(".Operation:first").show();

		$(".providerSection").each(
				function() {
					var tableOfContentsDiv = $(this).find('.tableOfContents');
					var tableHtml = "<table ><tr><td><ul>";
					var tocContents = $(this).find(
							"a[isToCAnchor=true]");

					var middleOfList = Math.ceil(tocContents.length / 2) - 1;
					for ( var i = 0; i < tocContents.length; i++) {
						tableHtml += "<li ><a href='#"
								+ $(tocContents[i]).attr("name") + "'>"
								+ $(tocContents[i]).attr("anchorLabel")
								+ "</a></li>";
						if (i == middleOfList) {
							tableHtml += "</ul></td><td><ul>";
						}
					}

					tableHtml += "</ul></td>";
					
					var sampleAppUrl = $(this).find("input[name=sample-app-url]").val();
					var tutorialUrl = $(this).find("input[name=tutorial-url]").val();
					var apiServiceHeader = $("span.apiServiceHeaderLabel").text();
					if(sampleAppUrl != "" || tutorialUrl != ""){
						tableHtml +="<td><ul>";
						if(sampleAppUrl != "" ){
							tableHtml += "<li><a href='" + sampleAppUrl + "'>"+apiServiceHeader+" Sample Apps</a></li>";
						}
						if(tutorialUrl != "" ){
							tableHtml += "<li><a href='" + tutorialUrl + "'>"+apiServiceHeader+" Tutorials</a></li>";
						}
						tableHtml +="</ul></td>";
					}
					
					tableHtml +="</tr></table>";

					tableOfContentsDiv.html(tableHtml);

				});
		
		$("#methodSelect").change(function() {
			var selectedMethod = $("#methodSelect").val();
			showOnlySelectedMethod(selectedMethod);
		});
		
		$("#environmentSelect option[externalLink='']").remove();
		
		$("#environmentSelect").change(function() {
			var environmentSelect = $("#environmentSelect");
			if (environmentSelect.val() != "rest") {
				var externalUrl = $('option:selected', environmentSelect).attr('externalLink');
				var externalWin = window.open(externalUrl, environmentSelect.val());
				if(externalWin) {
					externalWin.focus();
				}
			}
			
			$("#environmentSelect").val("rest");
		});

		$("table.parametersTable tr:odd").addClass("parameterAlternateRow");
		$("table.errorsTable tr:odd").addClass("errorsAlternateRow");

		selectDefaultMethod(operationId);
		decorateNavigation("apis");
		selectVersionInHeader();
	};

	//public
	this.headerInit = function() {
		$("#serviceVersionDropDown").change(function() {
			var versionSelect = $("#serviceVersionDropDown");
			var versionUrl = $('option:selected', versionSelect).attr('apiDocServiceUrl');
			window.location.href = versionUrl;
		});
	};

	//public
	this.errorPageInit = function() {
		$("table.errorsTable tr:odd").addClass("errorsAlternateRow");
		decorateNavigation("errors");
	};

	//public 
	this.getUrlParam = function(key) {
		key = key.replace(/[*+?^$.\[\]{}()|\\\/]/g, "\\$&"); // escape RegEx meta
		// chars
		var match = location.search
				.match(new RegExp("[?&]" + key + "=([^&]+)(&|$)"));
		return match && decodeURIComponent(match[1].replace(/\+/g, " "));
	};

	//public
	this.searchErrorCodes = function() {
		var searchTerm = $("input[name=errorSearchInput]").val();

		if (searchTerm == null || searchTerm == '') {
			$("#searchResultsSection").removeClass("hidden");
			$("#searchResultsText").text("Please enter an error code.");
			return;
		}

		searchTerm = padErrorCode(searchTerm);

		var matchingElements = $(".errorsTable a[href*=" + searchTerm + "]")
				.filter(function() {
					var matched = "" + this.href.match(new RegExp(/error\/[\d]{7}\/detail/));
					var errorCode = matched.substring(6, 11);
					return searchTerm == errorCode;
				});

		if (matchingElements.size() > 0) {
			matchingElements[0].click();
		} else {
			$("#searchResultsSection").removeClass("hidden");
			$("#searchResultsText").text("No Results found.  Please try again.");
			return;
		}
	};
	
	//private
	function selectVersionInHeader() {
		var currentVersion = $("input[name=version]").val();
		var versionSelector = $("#serviceVersionDropDown");
		if (versionSelector) {
			versionSelector.val(currentVersion);
		}
	};

	//private
	function findProviderTabIndex(methodName, providerName) {
		var index = 0;
		var matchedIndex = 0;
		$("div#provider-tabs" + methodName + " > ul a").filter(function() {
			if (this.name.toUpperCase() != providerName.toUpperCase()) {
				index++;
			} else {
				matchedIndex = index;
				return matchedIndex;
			}
		});
		return matchedIndex;
	};

	//private
	function decorateNavigation(navigationPath) {
		$(".menuList a").removeClass("selected").removeClass("parentLevel");

		if (navigationPath == "apis") {
			var apiNumber = $("input[name=apiNumber]").val();
			$(".menuList a[id*=" + apiNumber + "-]").addClass("selected");
			$(".menuList a#apis").addClass("parentLevel");
		} else {
			$(".menuList a#errors").addClass("selected").addClass("parentLevel");
		}
	};

	//private
	function selectDefaultMethod(operationId) {
		$("#methodSelect option").filter(function() {
			var matched = this.value == operationId;
			if (matched) {
				showOnlySelectedMethod(operationId);
			}
			return matched;
		}).attr('selected', true);

	};

	//private
	function showOnlySelectedMethod(selectedOptionValue) {
		$(".Operation").hide();
		$("div#" + selectedOptionValue).show();
		var parsedApiUrlObj = new ParsedApiUrl(window.location.href);
		var providerName = parsedApiUrlObj.provider;
		var operationNumber = selectedOptionValue.match(new RegExp(/[\d]+/));

		var selectedProviderTab = findProviderTabIndex(operationNumber, providerName);
		$("div[id*=provider-tabs]").tabs("option", "selected", selectedProviderTab);
	};

	//private
	function padErrorCode(errCode) {
		var pad = "00000";
		return pad.substring(0, pad.length - errCode.length) + errCode;
	};
	
	//private
	function ParsedApiUrl(urlString) {
		var path = urlString.replace(/.*docs\/apis\/rest/i, '');
		var parts = path.split('/');
		
		this.version = decodeURIComponent(parts[1]);
		this.api = decodeURIComponent(parts[2]);
		this.methodName = decodeURIComponent(parts[3]) || '';
		this.provider = decodeURIComponent(parts[4]) || '';
	};
	
	//private
	function getOperationId(methodName) {
		var operationId = 0;
		$("#methodSelect option").filter(function () { 
			if($(this).text().toUpperCase() == methodName.toUpperCase()) {
				operationId = $(this).val();
				return true;
			}
		});
		return operationId;
	};
};