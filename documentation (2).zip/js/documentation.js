var apiDocService = new function() {
	
	//public
	this.apiPageInit = function() {	
		var methodName = apiDocService.getUrlParam('method');
		var selectedTabNumber = methodName == null ? 0 : 1;

		$("#overview-methods-tabs").tabs({
			selected : selectedTabNumber
		});
		$(".iNeedTabified").tabs();

		$(".Operation").hide();
		$(".Operation:first").show();

		$(".providerSection").each(
				function() {
					var tableOfContentsDiv = $(this).find('.tableOfContents');
					var tableHtml = "<table ><tr><td><ul>";
					var tocContents = $(this).find(
							"a[isToCAnchor=true]");

					var middleOfList = Math.ceil(tocContents.length / 2) - 1;
					for ( var i = 0; i < tocContents.length; i++) {
						tableHtml += "<li ><a href='#"
								+ $(tocContents[i]).attr("name") + "'>"
								+ $(tocContents[i]).attr("anchorLabel")
								+ "</a></li>";
						if (i == middleOfList) {
							tableHtml += "</ul></td><td><ul>";
						}
					}

					tableHtml += "</ul></td>";
					
					var sampleAppUrl = $(this).find("input[name=sample-app-url]").val();
					var tutorialUrl = $(this).find("input[name=tutorial-url]").val();
					var apiServiceHeader = $("span.apiServiceHeaderLabel").text();
					if(sampleAppUrl != "" || tutorialUrl != ""){
						tableHtml +="<td><ul>";
						if(sampleAppUrl != "" ){
							tableHtml += "<li><a href='" + sampleAppUrl + "'>"+apiServiceHeader+" Sample Apps</a></li>";
						}
						if(tutorialUrl != "" ){
							tableHtml += "<li><a href='" + tutorialUrl + "'>"+apiServiceHeader+" Tutorials</a></li>";
						}
						tableHtml +="</ul></td>";
					}
					
					tableHtml +="</tr></table>";

					tableOfContentsDiv.html(tableHtml);

				});
		
		$("#methodSelect").change(function() {
			var selectedMethod = $("#methodSelect").val();
			showOnlySelectedMethod(selectedMethod);
		});
		
		$("#environmentSelect option[externalLink='']").remove();
		
		$("#environmentSelect").change(function() {
			var environmentSelect = $("#environmentSelect");
			if (environmentSelect.val() != "rest") {
				var externalUrl = $('option:selected', environmentSelect).attr('externalLink');
				var externalWin = window.open(externalUrl, environmentSelect.val());
				externalWin.focus();
			}
			
			$("#environmentSelect").val("rest");
		});

		$("table.parametersTable tr:odd").addClass("parameterAlternateRow");
		$("table.errorsTable tr:odd").addClass("errorsAlternateRow");

		selectDefaultMethod(methodName);
		rewriteNavigationUrls();
		rewriteErrorCodeUrls();
		decorateNavigation("apis");
		selectVersionInHeader();
	};

	//public
	this.headerInit = function() {
		$("#serviceVersionDropDown").change(function() {
			var versionSelect = $("#serviceVersionDropDown");
			var versionUrl = $('option:selected', versionSelect).attr('apiDocServiceUrl');
			window.location.href = versionUrl;
		});
		rewriteHeaderOptions();
	};

	//public
	this.errorPageInit = function() {
		rewriteNavigationUrls();
		rewriteErrorCodeUrls();
		rewriteAffectedApiLinkUrls();
		$("table.errorsTable tr:odd").addClass("errorsAlternateRow");
		decorateNavigation("errors");
	};

	//public 
	this.getUrlParam = function(key) {
		key = key.replace(/[*+?^$.\[\]{}()|\\\/]/g, "\\$&"); // escape RegEx meta
		// chars
		var match = location.search
				.match(new RegExp("[?&]" + key + "=([^&]+)(&|$)"));
		return match && decodeURIComponent(match[1].replace(/\+/g, " "));
	};

	//public
	this.searchErrorCodes = function() {
		var searchTerm = $("input[name=errorSearchInput]").val();

		if (searchTerm == null || searchTerm == '') {
			$("#searchResultsSection").removeClass("hidden");
			$("#searchResultsText").text("Please enter an error code.");
			return;
		}

		searchTerm = padErrorCode(searchTerm);

		var matchingElements = $(".errorsTable a[href*=" + searchTerm + "]")
				.filter(function() {
					var matched = "" + this.href.match(new RegExp(/error=[\d]{7}/));
					var errorCode = matched.substring(6, 11);
					return searchTerm == errorCode;
				});

		if (matchingElements.size() > 0) {
			matchingElements[0].click();
		} else {
			$("#searchResultsSection").removeClass("hidden");
			$("#searchResultsText").text("No Results found.  Please try again.");
			return;
		}
	};
	
	//private
	function selectVersionInHeader() {
		var currentVersion = $("input[name=version]").val();
		var versionSelector = $("#serviceVersionDropDown");
		if (versionSelector) {
			versionSelector.val(currentVersion);
		}
	};

	//private
	function findTabIndex(methodName, providerName) {
		var index = 0;
		var matchedIndex = 0;
		$("div#provider-tabs" + methodName + " > ul a").filter(function() {
			if (this.name != providerName) {
				index++;
			} else {
				matchedIndex = index;
				return matchedIndex;
			}
		});
		return matchedIndex;
	};

	//private
	function decorateNavigation(navigationPath) {
		$(".menuList a").removeClass("selected").removeClass("parentLevel");

		if (navigationPath == "apis") {
			var apiNumber = $("input[name=apiNumber]").val();
			$(".menuList a[id*=" + apiNumber + "-]").addClass("selected");
			$(".menuList a#apis").addClass("parentLevel");
		} else {
			$(".menuList a#errors").addClass("selected").addClass("parentLevel");
		}
	};

	//private
	function rewriteHeaderOptions() {
		rewriteUrls(rewriteHeaderOptionsStandAlone, rewriteHeaderOptionsDevPortal);
	};

	//private
	function rewriteHeaderOptionsStandAlone() {
		var baseUrl = window.location.pathname.replace(/((REST|Errors).*)/, "");

		$("#apiDocServiceHeader option").each(function() {
			$(this).attr('apiDocServiceUrl', baseUrl + $(this).attr('apiDocServiceUrl'));
		});
	};

	//private
	function rewriteUrls(standAloneFunc, devPortalFunc) {
		var passedItemId = apiDocService.getUrlParam('passedItemId');
		if (passedItemId == null) {
			standAloneFunc();
		} else {
			devPortalFunc(passedItemId);
		}
	};

	//private
	function rewriteDevPortal(cssSelector, attributeName, passedItemId) {
		$(cssSelector).each(
				function() {
					var currentUrl = $(this).attr(attributeName);
					$(this).attr(attributeName, 
							getReplaceUrlForDevPortal(currentUrl, passedItemId));
				});
	};
	
	//private
	function rewriteHeaderOptionsDevPortal(passedItemId) {
		rewriteDevPortal("#apiDocServiceHeader option", "apiDocServiceUrl", passedItemId);
	};

	//private
	function rewriteNavigationUrls() {
		rewriteUrls(rewriteNavigationUrlsStandAlone, rewriteNavigationUrlsDevPortal);
	};
	
	//private
	function rewriteNavigationUrlsDevPortal(passedItemId) {
		var baseUrl = window.location.pathname.replace(/((basicTemplate\.jsp).*)/,
				"");

		$("ul.menuList a").each(
				function() {
					var currentUrl = $(this).attr('href');
					// Errors
					if (currentUrl.match(/Errors\/index\.html/)) {
						$(this).prop(
								'href',
								baseUrl + "basicTemplate.jsp?passedItemId="
										+ passedItemId + "&error=content");
					} else {
						$(this)
								.prop(
										'href',
										getReplaceUrlForDevPortal(currentUrl,
												passedItemId));

					}
				});
	};

	//private
	function rewriteNavigationUrlsStandAlone() {
		var baseUrl = window.location.pathname.replace(/((REST|Errors).*)/, "");

		$("ul.menuList a").each(function() {
			$(this).prop('href', baseUrl + $(this).attr('href'));
		});
	};

	//private
	function rewriteAffectedApiLinkUrls() {
		rewriteUrls(rewriteAffectedApiLinkUrlsStandAlone,
				rewriteAffectedApiLinkUrlsDevPortal);
	};

	//private
	function rewriteAffectedApiLinkUrlsStandAlone() {
		// Do Nothing
	};


	//private
	function getReplaceUrlForDevPortal(currentUrl, passedItemId) {
		var baseUrl = window.location.pathname.replace(/((basicTemplate\.jsp).*)/,
				"");

		var rewritten = currentUrl.replace(
				/.*?(REST)\/(.*?)\/(.*?)\/.*\.html(\?*)(.*)/,
				"basicTemplate.jsp\?passedItemId=" + passedItemId
						+ "&api=$2&version=$3&$5");

		return baseUrl + rewritten;
	};
	
	//private
	function rewriteAffectedApiLinkUrlsDevPortal(passedItemId) {
		rewriteDevPortal("div#affectedApiLinks a", "href", passedItemId);
	};

	//private
	function rewriteErrorCodeUrls() {
		rewriteUrls(rewriteErrorCodeUrlsStandAlone, rewriteErrorCodeUrlsDevPortal);
	};

	//private
	function rewriteErrorCodeUrlsDevPortal(passedItemId) {
		var baseUrl = window.location.pathname.replace(/((basicTemplate\.jsp).*)/,
				"");
		$(".errorsTable td a").each(
				function() {
					var currentUrl = $(this).attr('href');

					var rewritten = currentUrl.replace(/.*?([\w]{7})\.html/,
							"basicTemplate.jsp?passedItemId=" + passedItemId
									+ "&error=$1");
					$(this).prop('href', baseUrl + rewritten);
				});
		$(".errorsIndexLink").each(
				function() {
					$(this).prop(
							'href',
							baseUrl + "basicTemplate.jsp?passedItemId="
									+ passedItemId + "&error=content");
				});
	};

	//private
	function rewriteErrorCodeUrlsStandAlone() {
		$(".errorsTable td a").each(
				function() {
					var errorCodeFileName = $(this).attr('href');
					// change 0000003.html to error_detail.html?error=0000003
					var rewriteFileName = errorCodeFileName.replace(
							/([\w]{7})\.html/, "error_detail.html?error=$1");
					$(this).prop('href', rewriteFileName);
				});
	};

	//private
	function selectDefaultMethod(methodName) {
		var selectedOptionValue = 'operation' + methodName;
		$("#methodSelect option").filter(function() {
			var matched = this.value == selectedOptionValue;
			if (matched) {
				showOnlySelectedMethod(selectedOptionValue);
			}
			return matched;
		}).attr('selected', true);

	};

	//private
	function showOnlySelectedMethod(selectedOptionValue) {
		$(".Operation").hide();
		$("div#" + selectedOptionValue).show();

		var providerName = apiDocService.getUrlParam('provider');
		var operationNumber = selectedOptionValue.match(new RegExp(/[\d]+/));

		var selectedProviderTab = findTabIndex(operationNumber, providerName);
		$("div[id*=provider-tabs]").tabs("option", "selected", selectedProviderTab);
	};

	//private
	function padErrorCode(errCode) {
		var pad = "00000";
		return pad.substring(0, pad.length - errCode.length) + errCode;
	};
	
};